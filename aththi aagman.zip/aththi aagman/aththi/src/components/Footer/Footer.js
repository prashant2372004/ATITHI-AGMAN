// src/components/Footer.js
import React from "react";
import { FaFacebook, FaInstagram, FaTwitter, FaLinkedin } from "react-icons/fa";

const Footer = () => {
  return (
    <footer className="bg-black text-white py-10">
      <div className="container mx-auto px-4">
        {/* Top Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Left Section: Contact Info */}
          <div>
            <h2 className="text-2xl font-semibold text-yellow-500">Contact Us</h2>
            <p className="mt-2 text-gray-300">
              Submit your contact, we will get back to you.
            </p>
            <div className="mt-4 space-y-2">
              {/* Phone */}
              <div className="flex items-center space-x-2">
                <span className="text-yellow-500 text-lg">📞</span>
                <p>+91 909-999-9090</p>
              </div>
              {/* Email */}
              <div className="flex items-center space-x-2">
                <span className="text-yellow-500 text-lg">📧</span>
                <p>support@atithiagman.com</p>
              </div>
            </div>

            {/* Social Media Links */}
            <div className="mt-6">
              <h3 className="text-lg font-semibold">Follow us on</h3>
              <div className="flex space-x-4 mt-2">
                <a href="#" className="text-blue-500 hover:text-blue-700">
                  <FaFacebook size={24} />
                </a>
                <a href="#" className="text-pink-500 hover:text-pink-700">
                  <FaInstagram size={24} />
                </a>
                <a href="#" className="text-blue-400 hover:text-blue-600">
                  <FaTwitter size={24} />
                </a>
                <a href="#" className="text-blue-700 hover:text-blue-900">
                  <FaLinkedin size={24} />
                </a>
              </div>
            </div>
          </div>

          {/* Right Section: Contact Form */}
          <div>
            <form className="space-y-4">
              {/* Name Input */}
              <input
                type="text"
                placeholder="Enter Your Name"
                className="w-full px-4 py-2 rounded-md bg-gray-800 text-white placeholder-gray-400 focus:outline-none focus:ring focus:ring-yellow-500"
              />
              {/* Contact Number Input */}
              <input
                type="text"
                placeholder="Contact Number"
                className="w-full px-4 py-2 rounded-md bg-gray-800 text-white placeholder-gray-400 focus:outline-none focus:ring focus:ring-yellow-500"
              />
              {/* Message Input */}
              <textarea
                placeholder="Message"
                rows={3}
                className="w-full px-4 py-2 rounded-md bg-gray-800 text-white placeholder-gray-400 focus:outline-none focus:ring focus:ring-yellow-500"
              ></textarea>
              {/* Submit Button */}
              <button
                type="submit"
                className="w-full bg-yellow-500 hover:bg-yellow-600 text-black font-semibold py-2 rounded-md transition duration-300"
              >
                Submit
              </button>
            </form>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="mt-10 border-t border-gray-700 pt-5 text-center text-gray-400">
          &copy; {new Date().getFullYear()} All Rights Reserved By Atithi Agman.
        </div>
      </div>
    </footer>
  );
};

export default Footer;
