import React from "react";
import { Link } from "react-router-dom"; // Import Link for routing
import "./NavigationBar.css";
import logo from  "../img/ATITHI AGMAN 1.png";

const navigation = [
  { name: "What we offer", href: "/what_we_offer", current: true },
  { name: "Events", href: "/events", current: false },
  { name: "Contact Us", href: "/contact-us", current: false },
];


function NavigationBar() {
  return (
    <nav className="bg-black text-white py-4 px-6">
      <div className="container mx-auto flex justify-between items-center">
        {/* Logo Section */}
        <div className="flex items-center space-x-2">
        <img src={logo} alt="Logo" style={{ width: "70px", height: "80px" }} />
           <div>
          <h1 className="text-3xl font-bold text-yellow-500 pl-4">ATITHI AGMAN </h1>
          <p className="text-x font-bold text-yellow-500">Personalized Perfect. Memorable</p>
          </div>
        </div>

        {/* Navigation Links */}
        <ul className="hidden md:flex space-x-6">
          {navigation.map((item) => (
            <li key={item.name}>
              <Link
                to={item.href}
                className={`${item.current ? "text-yellow-500" : "text-gray-300"
                  } hover:text-yellow-500`}
              >
                {item.name}
              </Link>
            </li>
          ))}
        </ul>

        {/* Login/Signup Button */}
        <Link
          to="/login"
          className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold py-2 px-4 rounded-md transition duration-300"
        >
          Login/Signup
        </Link>
      </div>
    </nav>
  );
}

export default NavigationBar;
