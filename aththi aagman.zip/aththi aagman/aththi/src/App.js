// src/App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import InviteConfirmPage from './pages/InviteConfirmPage';
import Home from './pages/Home';
import LoginPage from './pages/LoginPage';
import SignupPage from './pages/SignupPage';
import CompanyAdminPage from './pages/CompanyAdminPage';
import EventOrganizerAdminPage from './pages/EventOrganizerAdminPage';
import WhatWeOffer from "./pages/WhatWeOffer"; // Import your WhatWeOffer component
import Events from "./pages/Events"; // Import Events page
import ContactUs from "./pages/ContactUs";

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home/>} />
        <Route path="/LoginPage" element={<LoginPage />} />
        <Route path="/signup" element={<SignupPage />} />
        <Route path="/invite-confirm" element={<InviteConfirmPage />} />
        <Route path="/company-admin" element={<CompanyAdminPage />} />
        <Route path="/event-organizer-admin" element={<EventOrganizerAdminPage />} />
        <Route path="/what_we_offer" element={<WhatWeOffer />} />
        <Route path="/Events" element={<Events />} />
        <Route path="/contact-us" element={<ContactUs />} />
      </Routes>
    </Router>
  );
};

export default App;
