// src/pages/CompanyAdminPage.js
import React from 'react';

const CompanyAdminPage = () => {
  return (
    <div className="company-admin">
      <h1>Company Admin Dashboard</h1>
      <p>Manage events, users, and settings here.</p>
    </div>
  );
};

export default CompanyAdminPage;
