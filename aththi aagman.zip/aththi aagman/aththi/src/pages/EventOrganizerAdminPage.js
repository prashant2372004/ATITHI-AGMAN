// src/pages/EventOrganizerAdminPage.js
import React from 'react';

const EventOrganizerAdminPage = () => {
  return (
    <div className="event-organizer-admin">
      <h1>Event Organizer Dashboard</h1>
      <p>Manage your events and attendees here.</p>
    </div>
  );
};

export default EventOrganizerAdminPage;
