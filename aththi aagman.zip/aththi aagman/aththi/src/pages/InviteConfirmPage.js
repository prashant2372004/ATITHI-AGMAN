// src/pages/InviteConfirmPage.js
import React from 'react';

const InviteConfirmPage = () => {
  return (
    <div className="invite-confirm">
      <h1>Invitation Confirmation</h1>
      <p>You have been invited to join the event.</p>
      <button>Accept</button>
      <button>Decline</button>
    </div>
  );
};

export default InviteConfirmPage;
