// src/pages/WhatWeOffer.js
import React from "react";

const WhatWeOffer = () => {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold text-yellow-500">What We Offer</h1>
      <p className="mt-4 text-gray-700">
        Welcome to our offerings page. Here, we provide a variety of services to make your experience memorable.
      </p>
    </div>
  );
};

export default WhatWeOffer;
