import React from 'react'
import NavigationBar from '../components/NavigationBar/NavigationBar'
import Footer from '../components/Footer/Footer'

function Home() {
  return (
    <div>
      <NavigationBar />
      image
      <Footer></Footer>
    </div>
  )
}

export default Home
